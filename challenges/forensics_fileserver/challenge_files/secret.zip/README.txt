Password policy for this archive:
- Starts with uppercase letter
- Contains '@' symbol
- Mix of letters and numbers
- 10 characters total
- Based on a common word related to the operation name
